# Brief: ZTE H288A parental-control ADD returns SUCC but creates no rule

## Router
- ZTE ZXHN H288A, firmware H288A V1.0_GR5.1T16, admin page 192.168.1.1, logged in as admin.
- The router keeps a SINGLE admin session: a second login evicts the first.
- All requests carry a `guid` (`_=` = millis timestamp) and `Referer: http://192.168.1.1/`.

## What is PROVEN working (do not change)
- Login (3 steps, entry FIRST): GET `/?_type=loginData&_tag=login_entry` (JSON sess_token) -> GET `/?_type=loginData&_tag=login_token` (numeric challenge) -> POST same URL with `action=login&Username=&Password=SHA256(password+challenge)&_sessionTOKEN=`. A browser-style `GET /` page load runs before login.
- Parental read: GET `/?_type=menuView&_tag=parentCtrl&Menu3Location=0` (HTML embeds `_sessionTmpToken`), then GET `/?_type=menuData&_tag=firewall_parentctrl_lua.lua`. Rules come back as ParaName/ParaValue pairs (`<ParaName>_InstID</ParaName><ParaValue>DEV.PCUser1</ParaValue>` ...). 6 rules sync: Ahmed, Rasha, Desktop, My TV, Tablet, Hyper.
- Instance TOGGLE (proven on the router's own page): POST to the data URL with `IF_ACTION=Apply, Enable=1/0, _InstID=DEV.PCUserN, _sessionTOKEN=<page token>`, plus a `Check` header: SHA256 hex of the urlencoded body, RSA-encrypted (PKCS1v15) with ZTE's hardcoded 2048-bit public key, base64 (fallback: plain SHA256 hex, then none). Strict SUCC check (`<IF_ERRORSTR>SUCC</IF_ERRORSTR>` and no `SessionTimeout`).
- Who's Online device list works (anonymous-session handshake + ParaName/ParaValue device parser).

## The problem (the ONLY remaining bug)
Creating a NEW parental rule from the app does NOT create a rule on the router, even though the router answers SUCC.

Exact request the app sends (after a FRESH admin login, page token fetched from the parentCtrl view right after that login):
- POST `/?_type=menuData&_tag=firewall_parentctrl_lua.lua&_={millis}`
- Body (urlencoded): `IF_ACTION=Add&Name=5CG2391C93-W10&UserIdentity=D6:9A:26:67:27:64&Enable=1&Action=Ban Internet Access&Days=Everyday&StartHour=0&StartMin=0&EndHour=23&EndMin=59&_sessionTOKEN=<page token>`
- Sent via the SAME signed-POST path as the proven toggle (Check header RSA -> plain SHA256 -> none).
- A plain unsigned POST of the same body was also tried earlier: same result.

Exact router reply (HTTP 200):
`<ajax_response_xml_root><IF_ERRORPARAM>SUCC</IF_ERRORPARAM><IF_ERRORTYPE>SUCC</IF_ERRORTYPE><IF_ERRORSTR>SUCC</IF_ERRORSTR><IF_ERRORID>0</IF_ERRORID><OBJ_PARENT_CONTROL_ID><Instance><ParaName>_InstID</ParaName><ParaValue>DEV.PCUser1</ParaValue><ParaName>StartHour</ParaName><ParaValue>0</ParaValue>...` (the full current rule list, starting with the first existing rule)
- A fresh GET of the data script right after still returns only the same 6 rules. No 7th rule (no DEV.PCUser7) is ever created.
- So the router ACKs the Add (SUCC) but does not create an instance.

## Question
What does the H288A GR5.1T16 web UI's "Create New Item" (Add) request send that this request does NOT? Give the EXACT Add request the web UI sends (URL, every form field name and value, headers), and name the missing field/value. Candidates you should evaluate explicitly:
1. An `_InstID` for the new instance (empty, or the next id such as DEV.PCUser7) — the web UI's Add form may submit one.
2. A different `Action` value than the display string "Ban Internet Access" (a code such as Ban/0/1/Deny).
3. A different `Days` value than "Everyday" (a bitmask or day list).
4. A different `UserIdentity` format (MAC without colons, lowercase, or a different field name).
5. Extra hidden fields from the Add form (e.g. a form token, IF_ERRORSTR, or an instance counter).
6. A different URL for Add (menuView instead of menuData, or a different _tag).
7. A two-step flow (e.g. Add must be preceded by a specific view load, or the rule must be added disabled then enabled).

## Notes
- The Name "5CG2391C93-W10" is a laptop hostname (starts with a digit, contains hyphens). The MAC is a locally-administered (randomized) address, stable across days.
- The app's next version (v1.9.0, building) will dump the Add-form HTML from the parentCtrl view into its Diagnostics report, so your answer can be checked against the real form. If you can, base your answer on the ZTE H288A/GR5.1T16 (or F680-family) web UI source, not on generic ZTE guesses.
- Answer with the exact corrected Add request (Kotlin-friendly field list). Do not rewrite the whole app; only the Add request is in question.
